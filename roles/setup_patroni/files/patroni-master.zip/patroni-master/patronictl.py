#!/usr/bin/env python
from patroni.ctl import ctl

if __name__ == '__main__':
    ctl(None)
